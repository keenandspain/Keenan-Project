package edu.tcu.cs.et.domain;

import java.io.Serializable;
import java.math.BigInteger; 

/**
 * Class Book is called JavaBean, it corresponds to the table Book in
 * Database. Each attribute in JavaBean corresponds to each field or column in
 * the table. There should also be setter and getter methods.
 * 
 * @author Bwei
 * @author keenandspain
 *
 */
public class Book implements Serializable {
	private String isbn;

	private String title;

	private Integer year;

	private String published_by;

	private String previous_edition;

	private Double price;

	/*
	 * Constructor that sets sets the parameters of the book object to the attributes of the object.
	 */
	public Book(String isbn, String title, Integer year, String published_by, String previous_edition, Double price) {
		this.isbn = isbn;
		this.title = title;
		this.year = year;
		this.published_by = published_by;
		this.previous_edition = previous_edition;
		this.price = price;
	}
	/*
	 * Creates book object with null attributes.
	 */
	public Book() {

	}

	/*
	 * (non-Javadoc)
	 * @see java.lang.Object#toString()
	 * Returns the book attributes in string form.
	 */
	@Override
	public String toString() {
		return "Book [isbn=" + isbn + ", title=" + title + ", year=" + year + ", published_by=" + published_by + ", previousEdition="
				+ previous_edition + ", price=" + price + "]";
	}

	/*
	 * returns the isbn of the book
	 */
	public String getIsbn() {
		return isbn;
	}
	/*
	 * sets the isbn of the book.
	 */
	public void setIsbn(String isbn) {
		this.isbn = isbn;
	}
	/*
	 * returns the title of the book.
	 */
	public String getTitle() {
		return title;
	}
/*
 * sets the title of the book.
 */
	public void setTitle(String title) {
		this.title = title;
	}
	/*
	 * returns the year of the book.
	 */
	public Integer getYear() {
		return year;
	}
	/*
	 * sets the year of the book.
	 */
	public void setYear(Integer year) {
		this.year = year;
	}
	/*
	 * returns the publisher of the book.
	 */
	public String getPublished_by() {
		return published_by;
	}
	/*
	 * sets the publisher of the book.
	 */
	public void setPublished_by(String published_by) {
		this.published_by = published_by;
	}
	/*
	 * returns the previous edition of the book.
	 */
	public String getPrevious_edition() {
		return previous_edition;
	}
	/*
	 * sets the previous edition of the book.
	 */
	public void setPrevious_edition(String previous_edition) {
		this.previous_edition = previous_edition;
	}
/*
 *  returns the price of the book.
 */
	public Double getPrice() {
		return price;
	}
	/* 
	 *  sets the price of the book. 
	 *  
	 */
	public void setPrice(Double price) {
		this.price = price;
	}

	// getters and setters
	
}
