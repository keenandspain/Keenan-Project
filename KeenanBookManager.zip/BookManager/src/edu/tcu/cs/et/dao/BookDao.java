package edu.tcu.cs.et.dao;
/*
 
 */

import java.math.BigInteger;
import java.sql.SQLException;
import java.util.List;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanListHandler;

import edu.tcu.cs.et.domain.Book;
import edu.tcu.cs.et.domain.Publisher;
import edu.tcu.cs.et.tools.JDBCUtils;

public class BookDao {
	private QueryRunner qr = new QueryRunner(JDBCUtils.getDataSource());

	/*
	 * Interacts with the database through sql statements and passed values of objects.
	 */
	
	/*
	 * Deletes book through passed isbn.
	 */
	public void deleteBook(String isbn) {
		try {
			// Write SQL statement with placeholder
			String sql = "DELETE FROM Book WHERE isbn=?";
			qr.update(sql, isbn);
		} catch (SQLException ex) {
			System.out.println(ex);
			throw new RuntimeException("Delete Exception!");
		}
	}

	/*
	 * Edits Book through by isbn.
	 */
	public void editBook(Book book) {
		try {
			// Write SQL statement with placeholder
			String sql = "UPDATE Book SET title=?,year=?,price=?,published_by=?,previous_edition=? WHERE isbn=?";
			//
			Object[] params = {book.getTitle(), book.getYear(),book.getPrice(), book.getPublished_by(),
					book.getPrevious_edition(),book.getIsbn() };
			//
			qr.update(sql, params);
		} catch (SQLException ex) {
			System.out.println(ex);
			throw new RuntimeException("Edit Exception!");
		}
	}

	/*
	 * Adds a book into the Book table in database.
	 */
	public void addBook(Book book) {
		try {
			// Write SQL statement with placeholder
			String sql = "INSERT INTO Book (isbn,title,year,published_by,previous_edition,price) VALUES(?,?,?,?,?,?)";
			// 
			Object[] params = { book.getIsbn(), book.getTitle(), book.getYear(), book.getPublished_by(),
					book.getPrevious_edition(),book.getPrice() };
			//
			qr.update(sql, params);
		} catch (SQLException ex) {
			System.out.println(ex);
			throw new RuntimeException("Add Exception!");
		}
	}
	/*
	 * Adds a Publisher into the Publisher table in database.
	 */
	public void addPublisher(Publisher publisher)
			{
				try {
					
					//write SQL STATEMENT.
					String sql = "Insert into Publisher (name,phone,city) VALUES (?,?,?)";
					Object[] params = { publisher.getName(), publisher.getPhone(),publisher.getCity() };
					qr.update (sql, params);
				}
				catch(SQLException e) {
					System.out.println(e);
					throw new RuntimeException("Add Exception");
				}
			}

	/*
	 * Returns books that have the passed isbn.
	 */
	public List<Book> selectIsbn(String isbn) {
		try {
			//
			String sql = "SELECT * FROM Book WHERE isbn = ? ";
			// Put the two parameters in an array
			Object[] params = { isbn };
			//
			return qr.query(sql, new BeanListHandler<>(Book.class), params);
		} catch (SQLException ex) {
			System.out.println(ex);
			throw new RuntimeException("Select Exception!");
		}
	}
	/*
	 * Returns books from book table that have the passed title.
	 */
	public List<Book> selectTitle(String title) {
		try {
			//
			String sql = "SELECT * FROM Book WHERE title = ? ";
			// Put the two parameters in an array
			Object[] params = { title };
			//
			return qr.query(sql, new BeanListHandler<>(Book.class), params);
		} catch (SQLException ex) {
			System.out.println(ex);
			throw new RuntimeException("Select Exception!");
		}
	}
	/*
	 * Returns Books that have the passed publisher.
	 */
	public List<Book> selectPublisher(String published_by) {
		try {
			//
			String sql = "SELECT * FROM Book WHERE published_by = ? ";
			// Put the two parameters in an array
			Object[] params = { published_by };
			//
			return qr.query(sql, new BeanListHandler<>(Book.class), params);
		} catch (SQLException ex) {
			System.out.println(ex);
			throw new RuntimeException("Select Exception!");
		}
	}
	/*
	 * Shows the books that have price between the passed values.
	 */
	public List<Book> selectPriceRange(Double minPrice, Double maxPrice) {
		try {
			//
			String sql = "SELECT * FROM Book WHERE price >= ? and price <= ?";
			// Put the two parameters in an array
			Object[] params = { minPrice,maxPrice };
			//
			return qr.query(sql, new BeanListHandler<>(Book.class), params);
		} catch (SQLException ex) {
			System.out.println(ex);
			throw new RuntimeException("Select Exception!");
		}
	}
	
	/*
	 * shows books that have the passed year value.
	 */
	public List<Book> selectYear(String year) {
		try {
			//
			String sql = "SELECT * FROM Book WHERE year = ? ";
			// Put the two parameters in an array
			Object[] params = { year };
			//
			return qr.query(sql, new BeanListHandler<>(Book.class), params);
		} catch (SQLException ex) {
			System.out.println(ex);
			throw new RuntimeException("Select Exception!");
		}
	}

	/*
	 * shows books that have the title and publisher that have been passed.
	 */
	public List<Book> selectTitlePublisher(String title,String publisher) {
		try {
			//
			String sql = "SELECT * FROM Book WHERE title = ? and published_by = ?";
			// Put the two parameters in an array
			Object[] params = { title, publisher };
			//
			return qr.query(sql, new BeanListHandler<>(Book.class), params);
		} catch (SQLException ex) {
			System.out.println(ex);
			throw new RuntimeException("Select Exception!");
		}
	}
	
	/*
	 * shows all of the books inside of the Book table.
	 */
	public List<Book> selectAll() {
		try {
			
			String sql = "SELECT * FROM Book";
			
			
			//
			List<Book> list = qr.query(sql, new BeanListHandler<>(Book.class));
			return list;
		} catch (SQLException ex) {
			System.out.println(ex);
			throw new RuntimeException("Select All Exception!");
		}
	}

}
