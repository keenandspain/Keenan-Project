package edu.tcu.cs.et.controller;

import java.util.List;

import edu.tcu.cs.et.domain.Book;
import edu.tcu.cs.et.domain.Publisher;
import edu.tcu.cs.et.service.BookService;

public class BookController {
	private BookService service = new BookService();
	/*
	 * Controller passes the isbn of book to BookService to be deleted.
	 */
	public void deleteBook(String isbn) {
		service.deleteBook(isbn);
	}
	
	/*
	 * Controller is calling BookService's editBook method and passing book to it.
	 */
	public void editBook(Book book) {
		service.editBook(book);
	}
	/*
	 * Controller is invoking the addBook method of BookService
	 * 
	 */
	public void addBook(Book book) {
		service.addBook(book);
	}
	/*
	 * Controller is invoking the addPublisher and passing it to service. 
	 */
	public void addPublisher(Publisher publisher)
	{
		service.addPublisher(publisher);
	}
	
	/*
	 * Controller passes isbn to BookService
	 * and returns the result to MainView
	 */
	public List<Book> selectIsbn(String isbn){
		return service.selectIsbn(isbn);
	}
	/*
	 * Controller passes title to BookService
	 * and returns the result to MainView
	 */
	public List<Book> selectTitle(String title){
		return service.selectTitle(title);
	}
	/*
	 * Controller passes publisher to BookService
	 * and returns the result to MainView
	 */
	public List<Book> selectPublisher(String publisher){
		return service.selectPublisher(publisher);
	}
	/*
	 * Controller passes Price range to BookService
	 * and returns the result to MainView
	 */
	public List<Book> selectPriceRange(Double minPrice,Double maxPrice){
		return service.selectPriceRange(minPrice,maxPrice);
	}
	/*
	 * Controller passes year to BookService
	 * and returns the result to MainView
	 */
	public List<Book> selectYear(String year){
		return service.selectYear(year);
	}
	/*
	 * Controller passes title and publisher to BookService
	 * and returns the result to MainView
	 */
	public List<Book> selectTitlePublisher(String title,String publisher){
		return service.selectTitlePublisher(title,publisher);
	}
	
	/*
	 * Controller is calling BookService's selectAll method.
	 */
	public List<Book> selectAll(){
		return service.selectAll();
	}
}
