package edu.tcu.cs.et.view;
/*

 */

import java.util.List;
import java.util.Scanner;

import edu.tcu.cs.et.controller.BookController;
import edu.tcu.cs.et.domain.Book;
import edu.tcu.cs.et.domain.Publisher;

public class MainView {
	//MainView holds an instance of BookController.
	private BookController controller = new BookController();

	/*
	 * The control flow in run() is 1.print the menu 2.get the input from user
	 * 3.call the corresponding method to update or query the database 4.print
	 * results to user 5.go back to step 1 until the input is exit.
	 */
	public void run() {

		Scanner sc = new Scanner(System.in);
		while (true) {
			// print the menu
			System.out.println("---------------Book Manager---------------");
			System.out.println("1.Add Book 2.Edit Book 3.Delete Book 4.Search Book 5.Add Publisher 6.Exit");
			System.out.println("Please select the function, type [1-6] and press enter:");

			int choose = sc.nextInt();

			switch (choose) {
			case 1:
				addBook();
				break;
			case 2:
				editBook();
				break;
			case 3:
				deleteBook();
				break;
			case 4:
				selectBook();
				break;
			case 5:
				addPublisher();
			case 6:
				System.exit(0);
				break;
			}
		}
	}

	/*
	 * User Selects 1. to add a book.
	 * The user inputs the isbn, title, year, publisher,previous edition and price of the book
	 * through the console.
	 */
	public void addBook() {
		System.out.println("Please enter the following information:");
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Isbn of the Book:");
		String isbn = sc.nextLine();
		System.out.println("Enter title of Book:");
		String title = sc.nextLine();
		System.out.println("Enter book year:");
		String yearStr = sc.nextLine();
		Integer year = Integer.parseInt(yearStr);
		
		System.out.println("Enter the publisher of the book.");
		String published_by = sc.nextLine();
		System.out.println("Enter the previous edition of the book.");
		String previous_edition = sc.nextLine();
		if (previous_edition.equals("") || (previous_edition.equals(" ")))
		{
			previous_edition = null;
		}
		
		System.out.println("Enter the price of the book.");
		
		
		
		String priceStr = sc.nextLine();
		Double price = Double.parseDouble(priceStr);
		//Create an Book instance to hold the collected data
		Book book = new Book(isbn, title, year, published_by, previous_edition, price);
		//pass the object book to controller
		controller.addBook(book);
		System.out.println("Book Added Successfully!");
	}
	/*
	 * the user enters the name,phone and city of the publisher that is being added to the publisher table.
	 */
	public void addPublisher()
	{
		System.out.println("Enter the name of the Publisher");
		Scanner sc = new Scanner(System.in);
		String name = sc.nextLine();
		System.out.println("Enter the phone number of the Publisher");
		String phone = sc.nextLine();
		System.out.println("Enter the city of the Publisher");
		String city = sc.nextLine();
		Publisher publisher = new Publisher (name, city, phone);
	}
	
	/*
	 * Edits the columns of a book specified by isbn.
	 */
	public void editBook() {
		// We first display all books to user.
		selectAll();
		System.out.println("Which Book do you want to edit?");
		Scanner sc = new Scanner(System.in);
		System.out.print("Type Isbn and press enter:");
		String isbn = sc.nextLine();
		System.out.println("Enter new Title:");
		String title = sc.nextLine();
		System.out.println("Enter new Year of Book:");
		Integer year = Integer.parseInt(sc.nextLine());
		System.out.println("Enter new publisher:");
		String published_by = sc.nextLine();
		System.out.println("Enter new Previous_edition:");
		String previous_edition = sc.nextLine();
		if (previous_edition.equals("") || (previous_edition.equals(" ")))
		{
			previous_edition = null;
		}
		System.out.println("Enter new price:");
		String priceStr = sc.nextLine();
		Double price = Double.parseDouble(priceStr);
		
		// Create an Book instance to encapsulate all the data above
		Book book = new Book(isbn, title, year, published_by, previous_edition, price);
		// pass the object to controller
		controller.editBook(book);
		System.out.println("Edit Successfully!");
	}
	/*
	 * searches for a book based on criteria or all books by interacting with the console.
	 */
	public void selectBook() {
		System.out.println("1. Search All Books 2. Search based on Isbn 3. Search based on Title 4. Search based on publisher \n 5. Search based on Price range 6. Search based on year 7. Search based on title and publisher :");
		Scanner sc = new Scanner(System.in);
		int selectChooser = sc.nextInt();
		switch (selectChooser) {
		case 1:
			// select all books from DB
			selectAll();
			break;
		case 2:
			// select based on Isbn.
			selectAll();
			selectIsbn();
			break;
		case 3:
			// select based on Title.
			selectAll();
			selectTitle();
			break;
		case 4: 
			//select based on Publisher.
			selectAll();
			selectPublisher();
			break;
		case 5:
			//select based on Price range.
			selectAll();
			selectPriceRange();
			break;
		case 6: 
			//select based on Year.
			selectAll();
			selectYear();
			break;
		case 7: 
			selectAll();
			selectTitlePublisher();
			//select based on Title and Publisher.
			
			}
	}

	/*
	 * Selects all books from the book table
	 */
	public void selectAll() {
		// Call ActivityController's selectAll method
		
		List<Book> list = controller.selectAll();
		if (list.size() != 0)
			print(list);
		else
			System.out.println("No Book is found!");
	}

	/*
	 * Returns the books based on the given isbn inputed by the user.
	 */
	public void selectIsbn() {
		System.out.println("2. Search based on Isbn");
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter Isbn:");
		String isbn = sc.nextLine();
		List<Book> list = controller.selectIsbn(isbn);
		if (list.size() != 0)
			print(list);
		else
			System.out.println("No Book is found with the specified isbn !");
	}
	
	/*
	 * Returns the books based on the given title inputed by the user.
	 */
	public void selectTitle() {
		System.out.println("3. Search based on Title");
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter Title: ");
		String title = sc.nextLine();
		List<Book> list = controller.selectTitle(title);
		if (list.size() != 0)
			print(list);
		else
			System.out.println("No Book is found with the specified title !");
	}
	/*
	 * Returns the books based on the given publisher inputed by the user.
	 */
	
	public void selectPublisher() {
		System.out.println("3. Search based on Publisher");
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter Publisher: ");
		String publisher = sc.nextLine();
		List<Book> list = controller.selectPublisher(publisher);
		if (list.size() != 0)
			print(list);
		else
			System.out.println("No Book is found with the specified publisher name !");
	}
	/*
	 * Returns the books based on the given price range inputed by the user.
	 */
	public void selectPriceRange() {
		System.out.println("3. Search based on Price Range");
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter Min Price: ");
		String minPriceStr = sc.nextLine();
		Double minPrice= Double.parseDouble(minPriceStr);
		System.out.print("Enter Max Price: ");
		String maxPriceStr = sc.nextLine();
		Double maxPrice= Double.parseDouble(maxPriceStr);
		List<Book> list = controller.selectPriceRange(minPrice,maxPrice);
		if (list.size() != 0)
			print(list);
		else
			System.out.println("No Book is found with the specified Price Range !");
	}
	/*
	 * Returns the books based on the given year inputed by the user.
	 */
	public void selectYear() {
		System.out.println("3. Search based on Year");
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter Year: ");
		String year = sc.nextLine();
		List<Book> list = controller.selectYear(year);
		if (list.size() != 0)
			print(list);
		else
			System.out.println("No Book is found with the specified publisher name !");
	}
	
	/*
	 * Returns the books based on the given title and publisher inputed by the user.
	 */
	public void selectTitlePublisher() {
		System.out.println("3. Search based on Title and Publisher");
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter Title: ");
		String title = sc.nextLine();
		System.out.print("Enter Publisher: ");
		String publisher = sc.nextLine();

		List<Book> list = controller.selectTitlePublisher(title,publisher);
		if (list.size() != 0)
			print(list);
		else
			System.out.println("No Book is found with the specified publisher name and title !");
	}
	
	/*
	 * Deletes a book based on the given isbn given by the user in the conosle.
	 */
	public void deleteBook() {
		// First, we display all existing Books to user
		selectAll();
		System.out.println("Enter the Isbn of the book you want to delete and press enter:");
		String isbn = new Scanner(System.in).nextLine();
		// pass the isbn to the controller
		controller.deleteBook(isbn);
		System.out.println("Book is deleted.");
	}
	private void print(List<Book> list) {
		System.out.printf("%-5s %-25s %-35s%-15s%-15s%-30s%n", "Isbn", "Title", "Year", "published_by", "previous_edition", "Price");
		System.out.println("---------------------------------------------------------------------------------------------------------------------------");
		// Iterate the list and print each item to console
		for (Book book : list) {
			System.out.printf("%-5s %-25s %-35s%-15s%-15s%-30s%n", book.getIsbn(), book.getTitle(), book.getYear(), book.getPublished_by(),
					book.getPrevious_edition(),book.getPrice());
		}
	}
}
