package edu.tcu.cs.et.service;

import java.util.List;

import edu.tcu.cs.et.dao.BookDao;
import edu.tcu.cs.et.domain.Book;
import edu.tcu.cs.et.domain.Publisher;

/*
 * The service class is responsible for the passing of attributes of the book to the DAO class to interact with the Database.
 */
public class BookService {
	private BookDao dao = new BookDao();
	/*
	 * Service passes the attribute of an book instance to DAO
	 */
	public void deleteBook(String isbn) {
		dao.deleteBook(isbn);
	}
	
	/*
	 * Service passes the book object to be editted.
	 */
	public void editBook(Book book) {
		dao.editBook(book);
	}
	
	/*
	 * Service passes the book object to be added.
	 */
	public void addBook(Book book) {
		dao.addBook(book);
	}
	/*
	 * Service passes the publisher object to be added.
	 */
	public void addPublisher(Publisher publisher)
	{
		dao.addPublisher(publisher);
	}
	/*
	 * Service passes the isbn attribute to be selected by.
	 */
	public List<Book> selectIsbn(String isbn)
	{
		return dao.selectIsbn(isbn);
	}
	/*
	 * Service passes the title attribute to be selected by.
	 */

	public List<Book> selectTitle (String title )
	{
		return dao.selectTitle(title);
		
	}
	/*
	 * Service passes the published_by attribute to be selected by.
	 */
	public List<Book> selectPublisher (String publisher )
	{
		return dao.selectPublisher(publisher);
		
	}
	/*
	 * Service passes the min and max price values to be searched by.
	 */
	public List<Book> selectPriceRange (Double minPrice,Double maxPrice )
	{
		return dao.selectPriceRange(minPrice,maxPrice);
		
		
	}
	/*
	 * Service passes the year attribute to be searched by.
	 */
	public List<Book> selectYear(String year)
	{
		return dao.selectYear(year);
	}
	/*
	 * Service passes the title and published_by attributes to be selected by.
	 */
	public List<Book> selectTitlePublisher(String title,String publisher)
	{
		return dao.selectTitlePublisher(title,publisher);
	}
	
	/*
	 * service passes the books to be selected.
	 */
	public List<Book> selectAll(){
		return dao.selectAll();
	}

	
	
}
